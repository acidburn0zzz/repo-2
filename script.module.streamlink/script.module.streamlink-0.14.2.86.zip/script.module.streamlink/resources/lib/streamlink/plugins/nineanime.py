# Plugin removed - https://github.com/streamlink/streamlink/issues/1862
