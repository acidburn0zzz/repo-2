# Plugin removed, see https://github.com/streamlink/streamlink/issues/1858
