script.module.websocket
=======================

websocket-client library repacked for Kodi

- https://github.com/back-to/script.module.websocket

Based on websocket-client library for Python.

- https://github.com/websocket-client/websocket-client

License
-------

LGPL
